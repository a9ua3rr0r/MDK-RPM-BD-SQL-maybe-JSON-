﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LR_DB.Model;
using LR_DB.Helper;

namespace LR_DB.View
{
    public partial class WindowGroupEdit : Window
    {
        private readonly UniversamDbContext db;
        public GroupOfProduct Group { get; private set; }
        private readonly bool isEdit;

        public WindowGroupEdit(UniversamDbContext context, GroupOfProduct group = null)
        {
            InitializeComponent();
            db = context;

            if (group == null)
            {
                Group = new GroupOfProduct();
                isEdit = false;
            }
            else
            {
                Group = group;
                isEdit = true;
                txtName.Text = Group.namegroup;
            }
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название группы", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Group.namegroup = txtName.Text.Trim();
            DialogResult = true;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}