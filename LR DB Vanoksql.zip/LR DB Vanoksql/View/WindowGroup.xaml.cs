﻿using LR_DB.Helper;
using LR_DB.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LR_DB.View
{
    public partial class WindowGroups : Window
    {
        private UniversamDbContext db;

        public WindowGroups()
        {
            InitializeComponent();
            db = new UniversamDbContext();
            LoadGroups();
        }

        private void LoadGroups()
        {
            db.GroupOfProducts.Load();
            dgGroups.ItemsSource = db.GroupOfProducts.Local.ToObservableCollection();
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new WindowGroupEdit(db);
            if (editWindow.ShowDialog() == true)
            {
                db.GroupOfProducts.Add(editWindow.Group);
                db.SaveChanges();
                LoadGroups();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (dgGroups.SelectedItem is GroupOfProduct selectedGroup)
            {
                var groupFromDb = db.GroupOfProducts.FirstOrDefault(g => g.idgroup == selectedGroup.idgroup);
                if (groupFromDb == null) return;

                var editWindow = new WindowGroupEdit(db, groupFromDb);
                if (editWindow.ShowDialog() == true)
                {
                    db.Entry(groupFromDb).State = EntityState.Modified;
                    db.SaveChanges();

                    dgGroups.Items.Refresh();
                }
            }
            else
            {
                MessageBox.Show("Выберите группу для редактирования");
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgGroups.SelectedItem is GroupOfProduct selectedGroup)
            {
                if (MessageBox.Show($"Удалить группу: {selectedGroup.namegroup}?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    db.GroupOfProducts.Remove(selectedGroup);
                    db.SaveChanges();
                    LoadGroups();
                }
            }
        }
    }
}