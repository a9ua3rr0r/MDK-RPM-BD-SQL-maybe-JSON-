﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LR_DB.Helper;
using LR_DB.Model;

namespace LR_DB.View
{
    public partial class WindowManufacturerEdit : Window
    {
        public Manufacturer Manufacturer { get; private set; }
        private readonly UniversamDbContext db;
        private readonly bool isEditMode;

        public WindowManufacturerEdit(UniversamDbContext context)
        {
            InitializeComponent();
            db = context;
            Manufacturer = new Manufacturer();
            this.DataContext = Manufacturer;
        }

        public WindowManufacturerEdit(UniversamDbContext context, Manufacturer existingManufacturer)
        {
            InitializeComponent();
            db = context;
            Manufacturer = existingManufacturer;
            tbName.Text = Manufacturer.nameManufacturer;
            tbAddress.Text = Manufacturer.address;
            isEditMode = true;
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbName.Text) || string.IsNullOrWhiteSpace(tbAddress.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            Manufacturer.nameManufacturer = tbName.Text;
            Manufacturer.address = tbAddress.Text;

            this.DialogResult = true;
            this.Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}