﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LR_DB.Helper;
using Microsoft.EntityFrameworkCore;
using LR_DB.Model;
using System.Linq;

namespace LR_DB.View
{
    public partial class WindowManufacturer : Window
    {
        private UniversamDbContext db;

        public WindowManufacturer()
        {
            InitializeComponent();
            db = new UniversamDbContext();
            LoadManufacturers();
        }

        private void LoadManufacturers()
        {
            db.Manufacturers.Load();
            dgManufacturers.ItemsSource = db.Manufacturers.Local.ToObservableCollection();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new WindowManufacturerEdit(db);
            if (editWindow.ShowDialog() == true)
            {
                db.Manufacturers.Add(editWindow.Manufacturer);
                db.SaveChanges();
                dgManufacturers.Items.Refresh(); 
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (dgManufacturers.SelectedItem is Manufacturer selectedManufacturer)
            {
                var manufacturerFromDb = db.Manufacturers.FirstOrDefault(m => m.idManufacturer == selectedManufacturer.idManufacturer);
                if (manufacturerFromDb == null) return;

                var editWindow = new WindowManufacturerEdit(db, manufacturerFromDb);
                if (editWindow.ShowDialog() == true)
                {
                    db.Entry(manufacturerFromDb).State = EntityState.Modified;
                    db.SaveChanges();
                    dgManufacturers.Items.Refresh();
                }
            }
            else
            {
                MessageBox.Show("Выберите производителя для редактирования");
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgManufacturers.SelectedItem is Manufacturer selectedManufacturer)
            {
                if (MessageBox.Show($"Удалить производителя: {selectedManufacturer.nameManufacturer}?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    db.Manufacturers.Remove(selectedManufacturer);
                    db.SaveChanges();
                    dgManufacturers.Items.Refresh(); 
                }
            }
        }
    }
}