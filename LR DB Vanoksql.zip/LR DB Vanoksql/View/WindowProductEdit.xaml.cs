﻿using LR_DB.Helper;
using LR_DB.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using Microsoft.EntityFrameworkCore;

namespace LR_DB.View
{
    public partial class WindowProductEdit : Window
    {
        private UniversamDbContext db;
        public Product Product { get; private set; }
        private bool isEdit;

        public WindowProductEdit(UniversamDbContext context, Product product = null)
        {
            InitializeComponent();
            db = context;
            LoadManufacturers();
            LoadGroups();

            if (product == null)
            {
                Product = new Product();
                isEdit = false;
            }
            else
            {
                Product = product;
                isEdit = true;

                txtName.Text = Product.nameProduct;
                txtPrice.Text = Product.priceProduct.ToString("0.00");
                txtDiscount.Text = Product.discountProduct?.ToString("0.00") ?? "";
                cmbManufacturer.SelectedValue = Product.idManufacturer;
                cmbGroup.SelectedValue = Product.idGroup;
            }
        }

        private void LoadManufacturers()
        {
            var manufacturers = db.Manufacturers.ToList();
            cmbManufacturer.ItemsSource = manufacturers;
            cmbManufacturer.DisplayMemberPath = "nameManufacturer";
            cmbManufacturer.SelectedValuePath = "idManufacturer";
        }

        private void LoadGroups()
        {
            var groups = db.GroupOfProducts.ToList();

            if (groups.Count == 0)
                MessageBox.Show("Группы не загружены! Проверь таблицу GroupOfProduct.");

            cmbGroup.ItemsSource = groups;
            cmbGroup.DisplayMemberPath = "namegroup";
            cmbGroup.SelectedValuePath = "idgroup";
        }


        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название товара", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (cmbManufacturer.SelectedValue == null || cmbGroup.SelectedValue == null)
            {
                MessageBox.Show("Выберите производителя и группу", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!double.TryParse(txtPrice.Text, out double price) || price < 0)
            {
                MessageBox.Show("Некорректная цена (должна быть неотрицательным числом)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            double? discount = null;
            if (!string.IsNullOrWhiteSpace(txtDiscount.Text))
            {
                if (!double.TryParse(txtDiscount.Text, out double parsedDiscount) || parsedDiscount < 0)
                {
                    MessageBox.Show("Некорректная скидка (должна быть неотрицательным числом)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                discount = parsedDiscount;
            }

            Product.nameProduct = txtName.Text.Trim();
            Product.priceProduct = price;
            Product.discountProduct = discount;
            Product.idManufacturer = (int)cmbManufacturer.SelectedValue;
            Product.idGroup = (int)cmbGroup.SelectedValue;

            DialogResult = true;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}