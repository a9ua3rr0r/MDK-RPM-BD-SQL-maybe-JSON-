﻿using LR_DB.Helper;
using LR_DB.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LR_DB.View
{
    public partial class WindowProducts : Window
    {
        private UniversamDbContext db;

        public WindowProducts()
        {
            InitializeComponent();
            db = new UniversamDbContext();
            LoadProducts();
        }

        private void LoadProducts()
        {
            // Попробуем без очистки локального кеша
            db.Products.Include(p => p.Manufacturer).Include(p => p.Group).Load();
            dgProducts.ItemsSource = null;
            dgProducts.ItemsSource = db.Products.Local.ToObservableCollection();

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new WindowProductEdit(db);
            if (editWindow.ShowDialog() == true)
            {
                db.Products.Add(editWindow.Product);
                db.SaveChanges();
                LoadProducts();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product selectedProduct)
            {
                var productFromDb = db.Products
                    .Include(p => p.Manufacturer)
                    .Include(p => p.Group)
                    .FirstOrDefault(p => p.idProduct == selectedProduct.idProduct); // ← замена здесь

                if (productFromDb == null) return;

                var editWindow = new WindowProductEdit(db, productFromDb);
                if (editWindow.ShowDialog() == true)
                {
                    db.SaveChanges();
                    LoadProducts();
                }
            }
            else
            {
                MessageBox.Show("Выберите продукт для редактирования");
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product selectedProduct)
            {
                if (MessageBox.Show($"Удалить продукт: {selectedProduct.Name}?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    db.Products.Remove(selectedProduct);
                    db.SaveChanges();
                    LoadProducts();
                }
            }
        }
    }
}