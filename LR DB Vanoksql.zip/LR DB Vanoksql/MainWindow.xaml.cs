﻿using System.Text;
using System.Windows;
using LR_DB.View;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LR_DB
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        

        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void Manufacturer_OnClick(object sender, RoutedEventArgs e)
        {
            WindowManufacturer wMan = new WindowManufacturer();
            wMan.Show();
        }

        private void Group_OnClick(object sender, RoutedEventArgs e)
        {
            WindowGroups wGr = new WindowGroups();
            wGr.Show();
        }

        public static int IdRole { get; set; }
        public static int IdEmployee { get; set; }

        private void Product_OnClick(object sender, RoutedEventArgs e)
        {
            WindowProducts wProd = new WindowProducts();
            wProd.Show();
        }
    }
}
    
