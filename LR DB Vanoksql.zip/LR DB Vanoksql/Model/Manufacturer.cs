﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LR_DB.Model
{
    [Table("Manufacturer")]
    public class Manufacturer
    {
        [Key]
        [Column("idManufacturer")]
        public int idManufacturer { get; set; }

        [Column("nameManufacturer")]
        public string nameManufacturer { get; set; }

        [Column("address")]
        public string address { get; set; }

        // Связь с продуктами
        public ICollection<Product> Products { get; set; }
    }
}