﻿using LR_DB.Helper;
using LR_DB.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

[Table("Product")]
public class Product
{
    [Key]
    public int idProduct { get; set; }

    [Column("nameProduct")]
    public string nameProduct { get; set; }

    [Column("priceProduct")]
    public double priceProduct { get; set; }

    [Column("discountProduct")]
    public double? discountProduct { get; set; }

    [Column("idManufacturer")]
    public int? idManufacturer { get; set; }

    [Column("idGroup")]
    public int? idGroup { get; set; }

    [ForeignKey("idManufacturer")]
    public virtual Manufacturer Manufacturer { get; set; }

    [ForeignKey("idGroup")]
    public virtual GroupOfProduct Group { get; set; }

    [NotMapped]
    public int Id => idProduct;

    [NotMapped]
    public string Name => nameProduct;

    [NotMapped]
    public double Price => priceProduct;

    [NotMapped]
    public double? Discount => discountProduct;

    [NotMapped]
    public string ManufacturerName => Manufacturer?.nameManufacturer ?? "—";

    [NotMapped]
    public string GroupName => Group?.namegroup ?? "—";
}

