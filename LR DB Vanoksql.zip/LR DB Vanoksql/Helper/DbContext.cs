﻿using LR_DB.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LR_DB.Helper
{
    public class UniversamDbContext : DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<Manufacturer> Manufacturers { get; set; }
        public DbSet<GroupOfProduct> GroupOfProducts { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Подключение к SQLite
                optionsBuilder.UseSqlite("Data Source=baseforshopuniversam.db");
            }
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Если нужны конфигурации таблиц или названия, можно указать тут.
            // Например:
            modelBuilder.Entity<Manufacturer>().ToTable("Manufacturer");
            modelBuilder.Entity<Product>().ToTable("Product");
            modelBuilder.Entity<GroupOfProduct>().ToTable("GroupOfProduct");

            base.OnModelCreating(modelBuilder);
        }
    }
}
