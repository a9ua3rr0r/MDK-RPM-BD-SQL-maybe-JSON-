﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using LR_DB.Model;

namespace LR_DB.Helper
{
    public static class DataService
    {
        private static readonly string RolePath = "roles.json";
        private static readonly string PersonPath = "persons.json";

        public static void SaveRoles(ObservableCollection<Manufacturer> roles)
        {
            File.WriteAllText(RolePath, JsonSerializer.Serialize(roles));
        }

        public static ObservableCollection<Manufacturer> LoadRoles()
        {
            if (!File.Exists(RolePath)) return new ObservableCollection<Manufacturer>();
            return JsonSerializer.Deserialize<ObservableCollection<Manufacturer>>(File.ReadAllText(RolePath));
        }

        public static void SavePersons(ObservableCollection<Product> persons)
        {
            File.WriteAllText(PersonPath, JsonSerializer.Serialize(persons));
        }

        public static ObservableCollection<Product> LoadPersons()
        {
            if (!File.Exists(PersonPath)) return new ObservableCollection<Product>();
            return JsonSerializer.Deserialize<ObservableCollection<Product>>(File.ReadAllText(PersonPath));
        }
        public static void SavePersonsToFile(ObservableCollection<Product> persons, string path)
        {
            File.WriteAllText(path, JsonSerializer.Serialize(persons));
        }

        public static ObservableCollection<Product> LoadPersonsFromFile(string path)
        {
            if (!File.Exists(path)) return new ObservableCollection<Product>();
            return JsonSerializer.Deserialize<ObservableCollection<Product>>(File.ReadAllText(path));
        }
        public static void SaveRolesToFile(ObservableCollection<Manufacturer> roles, string path)
        {
            File.WriteAllText(path, JsonSerializer.Serialize(roles));
        }

        public static ObservableCollection<Manufacturer> LoadRolesFromFile(string path)
        {
            if (!File.Exists(path)) return new ObservableCollection<Manufacturer>();
            return JsonSerializer.Deserialize<ObservableCollection<Manufacturer>>(File.ReadAllText(path));
        }

    }
}
